
import java.awt.Color;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 * @authors Diana Zepeda & Kevin Limón
 */
public class EstadoFinanciero extends javax.swing.JFrame {
    
    ArrayList<String> listPas = new ArrayList();
    ArrayList<String> listAct = new ArrayList();
    

    public EstadoFinanciero() {
        initComponents();
        GraphicsDevice Gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
        int width = Gd.getDisplayMode().getWidth();
        int height = Gd.getDisplayMode().getHeight();
        this.setSize(width,height);
        Color azul = new Color(62, 95, 138); // Color azul
        this.getContentPane().setBackground(azul); //Cambiar color de fondo
        setExtendedState(MAXIMIZED_BOTH);
        ButtonGroup group = new ButtonGroup();
        group.add(jrbActivo);
        group.add(jrbPasivo);
        
    }
    
    public int UltimoID(){
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        int id = 0;
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            java.sql.Statement st = conn.createStatement();
             
            //String total = String.valueOf(Integer.parseInt(txtCantidadP.getText())*Integer.parseInt(txtValUnP.getText()));
            String sql = "select * from estadofinanciero";
            ResultSet sel = st.executeQuery(sql);
            while(sel.next()){
                id = Integer.parseInt(sel.getString("id_estadof"));
            }
            st.executeUpdate(sql);
            conn.close();
            st.close();
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Error " + e);
        }  
        return id;
    }
    
     public void GuardarAct_Pas(){
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        int id = UltimoID();
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            java.sql.Statement st = conn.createStatement();
            String tipo = "";
            if(jrbActivo.isSelected()){
                tipo = "true"; //activo
            }else if(jrbPasivo.isSelected()){
                tipo = "false"; //pasivo
            }  
            String sql = "insert into activo_pasivo (id_estadof, nombre, monto, tipo)"
                    + "values(" + id + ",'" + txtNombreEF.getText() + "'," + txtMontoEF.getText() + "," + tipo +")";
            ResultSet result = st.executeQuery(sql);
            st.executeUpdate(sql);
            conn.close();
            st.close();
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Error " + e);
        }  
        JOptionPane.showMessageDialog(null, "Se ha guardado con exito");
    }
     
     public void NuevoEF(){
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        listPas.clear();
        listAct.clear();
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            java.sql.Statement st = conn.createStatement(); 
            //String total = String.valueOf(Integer.parseInt(txtCantidadP.getText())*Integer.parseInt(txtValUnP.getText()));
            String sql = "insert into estadofinanciero (fecha, totalpas, totalact)"
                    + "values('" + lblFechaAct.getText() + "',0,0)";
            st.executeUpdate(sql);
            conn.close();
            st.close();
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Error " + e);
        }  
    }
    
    public void ActualizarAct_Pas(){
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        int id = UltimoID();
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            java.sql.Statement st = conn.createStatement();  
            String tipo;
            if(jrbActivo.isSelected()){
                tipo = "true"; //activo
            }else{
                tipo = "false"; //pasivo
            }  
            String sql = "update activo_pasivo set nombre='" + txtMontoEF.getText() + "',monto=" + txtMontoEF.getText() + ",tipo=" +  
                    tipo + " where id_estadof=" + id;
            ResultSet result = st.executeQuery(sql);
            st.executeUpdate(sql);
            conn.close();
            st.close();
            
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Error " + e);
        }  
        JOptionPane.showMessageDialog(null, "Se ha actualizado con exito");
    }
    
    public void Calcular(){
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        int id = UltimoID();
        int totalAct = 0, totalPas = 0;
        for(int i = 0; i<listAct.size(); i++){
            totalAct = totalAct + Integer.parseInt(listAct.get(i));
        }
        for(int i = 0; i<listPas.size(); i++){
            totalPas = totalPas + Integer.parseInt(listPas.get(i));
        }
        lblTotalAct.setText(String.valueOf(totalAct));
        lblTotalPas.setText(String.valueOf(totalPas));
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            java.sql.Statement st = conn.createStatement();  
            
            //String total = String.valueOf(Integer.parseInt(txtCantidadP.getText())*Integer.parseInt(txtValUnP.getText()));
            String sql = "update estadofinanciero set totalpas='" + totalAct + "',totalact=" + totalPas + 
                    " where id_estadof=" + id;
            ResultSet result = st.executeQuery(sql);
            st.executeUpdate(sql);
            conn.close();
            st.close();
            
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Error " + e);
        }  
    }
    
    public void InsertarAct_Pas(){
        DefaultTableModel modelo = (DefaultTableModel) jTableEF.getModel(); 
        //modelo.setAutoResizeMode(jTableE.AUTO_RESIZE_OFF);
        String datos[] =  new String[3];
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        listPas.clear();
        listAct.clear();
        int id = UltimoID();
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            //JOptionPane.showMessageDialog(null, "BD conectada con exito");
            java.sql.Statement st = conn.createStatement();
            
            String sql = "select * from activo_pasivo where id_estadof="+ id;;
            ResultSet res = st.executeQuery(sql);
            
            while(res.next()){
                datos[0] = res.getString("nombre");
                datos[1] = res.getString("monto");
                if(res.getString("tipo").equals("t")){
                    datos[2] = "activo";
                    listAct.add(res.getString("monto"));
                }else{
                    datos[2] = "pasivo";
                    listPas.add(res.getString("monto"));
                }
                modelo.addRow(datos);
            }
            
            st.executeUpdate(sql);
            conn.close();
            st.close();
            
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Error " + e);
        }         
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        ISlbl = new javax.swing.JLabel();
        btnInicioP1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        Usuario_lbl3 = new javax.swing.JLabel();
        Usuario_lbl4 = new javax.swing.JLabel();
        Usuario_lbl5 = new javax.swing.JLabel();
        Usuario_lbl11 = new javax.swing.JLabel();
        txtNombreEF = new javax.swing.JTextField();
        txtMontoEF = new javax.swing.JTextField();
        jrbActivo = new javax.swing.JRadioButton();
        jrbPasivo = new javax.swing.JRadioButton();
        btnNuevoEF = new javax.swing.JButton();
        btnGuardarEF = new javax.swing.JButton();
        btnActualizarEF = new javax.swing.JButton();
        btnCancelarEF = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableEF = new javax.swing.JTable();
        Usuario_lbl8 = new javax.swing.JLabel();
        btnGenrerEF = new javax.swing.JButton();
        lblFechaAct = new javax.swing.JLabel();
        Usuario_lbl10 = new javax.swing.JLabel();
        lblTotalPas = new javax.swing.JLabel();
        Usuario_lbl13 = new javax.swing.JLabel();
        lblTotalAct = new javax.swing.JLabel();
        btnNuevoR = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        ISlbl.setFont(new java.awt.Font("Microsoft YaHei", 1, 36)); // NOI18N
        ISlbl.setForeground(new java.awt.Color(255, 255, 255));
        ISlbl.setText("ESTADO FINANCIERO");

        btnInicioP1.setBackground(new java.awt.Color(202, 223, 251));
        btnInicioP1.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnInicioP1.setForeground(new java.awt.Color(25, 55, 87));
        btnInicioP1.setText("Volver");
        btnInicioP1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInicioP1ActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(87, 131, 188));
        jPanel1.setLayout(null);

        Usuario_lbl3.setFont(new java.awt.Font("Microsoft YaHei", 1, 24)); // NOI18N
        Usuario_lbl3.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl3.setText("ACTIVO/PASIVO");
        jPanel1.add(Usuario_lbl3);
        Usuario_lbl3.setBounds(150, 20, 220, 50);

        Usuario_lbl4.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl4.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl4.setText("Nombre");
        jPanel1.add(Usuario_lbl4);
        Usuario_lbl4.setBounds(70, 70, 150, 50);

        Usuario_lbl5.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl5.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl5.setText("Monto");
        jPanel1.add(Usuario_lbl5);
        Usuario_lbl5.setBounds(70, 170, 150, 50);

        Usuario_lbl11.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl11.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl11.setText("Tipo");
        jPanel1.add(Usuario_lbl11);
        Usuario_lbl11.setBounds(70, 270, 190, 50);

        txtNombreEF.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtNombreEF.setEnabled(false);
        jPanel1.add(txtNombreEF);
        txtNombreEF.setBounds(70, 120, 380, 50);

        txtMontoEF.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtMontoEF.setEnabled(false);
        jPanel1.add(txtMontoEF);
        txtMontoEF.setBounds(70, 220, 380, 50);

        jrbActivo.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        jrbActivo.setForeground(new java.awt.Color(255, 255, 255));
        jrbActivo.setText("Activo");
        jrbActivo.setEnabled(false);
        jPanel1.add(jrbActivo);
        jrbActivo.setBounds(140, 320, 90, 30);

        jrbPasivo.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        jrbPasivo.setForeground(new java.awt.Color(255, 255, 255));
        jrbPasivo.setText("Pasivo");
        jrbPasivo.setEnabled(false);
        jPanel1.add(jrbPasivo);
        jrbPasivo.setBounds(290, 320, 90, 30);

        btnNuevoEF.setBackground(new java.awt.Color(202, 223, 251));
        btnNuevoEF.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnNuevoEF.setForeground(new java.awt.Color(25, 55, 87));
        btnNuevoEF.setText("Nuevo");
        btnNuevoEF.setEnabled(false);
        btnNuevoEF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoEFActionPerformed(evt);
            }
        });
        jPanel1.add(btnNuevoEF);
        btnNuevoEF.setBounds(80, 400, 120, 50);

        btnGuardarEF.setBackground(new java.awt.Color(202, 223, 251));
        btnGuardarEF.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnGuardarEF.setForeground(new java.awt.Color(25, 55, 87));
        btnGuardarEF.setText("Guardar");
        btnGuardarEF.setEnabled(false);
        btnGuardarEF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarEFActionPerformed(evt);
            }
        });
        jPanel1.add(btnGuardarEF);
        btnGuardarEF.setBounds(310, 400, 120, 50);

        btnActualizarEF.setBackground(new java.awt.Color(202, 223, 251));
        btnActualizarEF.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnActualizarEF.setForeground(new java.awt.Color(25, 55, 87));
        btnActualizarEF.setText("Actualizar");
        btnActualizarEF.setEnabled(false);
        btnActualizarEF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarEFActionPerformed(evt);
            }
        });
        jPanel1.add(btnActualizarEF);
        btnActualizarEF.setBounds(80, 480, 120, 50);

        btnCancelarEF.setBackground(new java.awt.Color(202, 223, 251));
        btnCancelarEF.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnCancelarEF.setForeground(new java.awt.Color(25, 55, 87));
        btnCancelarEF.setText("Cancelar");
        btnCancelarEF.setEnabled(false);
        btnCancelarEF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarEFActionPerformed(evt);
            }
        });
        jPanel1.add(btnCancelarEF);
        btnCancelarEF.setBounds(310, 480, 120, 50);

        jTableEF.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        jTableEF.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Monto", "Tipo"
            }
        ));
        jTableEF.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jTableEF.setRowHeight(35);
        jScrollPane1.setViewportView(jTableEF);
        if (jTableEF.getColumnModel().getColumnCount() > 0) {
            jTableEF.getColumnModel().getColumn(0).setPreferredWidth(350);
            jTableEF.getColumnModel().getColumn(1).setPreferredWidth(150);
            jTableEF.getColumnModel().getColumn(2).setPreferredWidth(150);
        }

        Usuario_lbl8.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl8.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl8.setText("Total Pasivos:");

        btnGenrerEF.setBackground(new java.awt.Color(202, 223, 251));
        btnGenrerEF.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnGenrerEF.setForeground(new java.awt.Color(25, 55, 87));
        btnGenrerEF.setText("Generar");
        btnGenrerEF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenrerEFActionPerformed(evt);
            }
        });

        lblFechaAct.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        lblFechaAct.setForeground(new java.awt.Color(255, 255, 255));

        Usuario_lbl10.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl10.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl10.setText("Fecha: ");

        lblTotalPas.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        lblTotalPas.setForeground(new java.awt.Color(255, 255, 255));

        Usuario_lbl13.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl13.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl13.setText("Total Activos:");

        lblTotalAct.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        lblTotalAct.setForeground(new java.awt.Color(255, 255, 255));

        btnNuevoR.setBackground(new java.awt.Color(202, 223, 251));
        btnNuevoR.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnNuevoR.setForeground(new java.awt.Color(25, 55, 87));
        btnNuevoR.setText("Nuevo Estado Financiero");
        btnNuevoR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoRActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(ISlbl, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(140, 140, 140)
                        .addComponent(btnInicioP1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(Usuario_lbl10)
                        .addGap(10, 10, 10)
                        .addComponent(lblFechaAct, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(Usuario_lbl13, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(lblTotalAct, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(Usuario_lbl8, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(lblTotalPas, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(120, 120, 120)
                        .addComponent(btnNuevoR)
                        .addGap(65, 65, 65)
                        .addComponent(btnGenrerEF, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 570, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(ISlbl, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnInicioP1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Usuario_lbl10, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblFechaAct, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Usuario_lbl13, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTotalAct, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Usuario_lbl8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTotalPas, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnNuevoR, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnGenrerEF, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnInicioP1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInicioP1ActionPerformed
        Contador ven=new Contador();
        ven.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnInicioP1ActionPerformed

    private void btnNuevoEFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoEFActionPerformed
        HabilitarTF();
        btnNuevoEF.setEnabled(false);
        btnGuardarEF.setEnabled(true);
        btnActualizarEF.setEnabled(false);
        btnCancelarEF.setEnabled(true); 
    }//GEN-LAST:event_btnNuevoEFActionPerformed

    private void btnGuardarEFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarEFActionPerformed
        if(txtNombreEF.getText().isEmpty() || txtMontoEF.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Ningun campo puede quedar vacio");
        }else{
            GuardarAct_Pas();
            DefaultTableModel modelo = (DefaultTableModel) jTableEF.getModel();
            Limpiar();
            DeshabilitarTF();
            btnNuevoEF.setEnabled(true);
            btnGuardarEF.setEnabled(false);
            btnActualizarEF.setEnabled(false);
            btnCancelarEF.setEnabled(false); 
            for( int i = modelo.getRowCount() - 1; i >= 0; i-- ) {
                modelo.removeRow(i);
            }
            InsertarAct_Pas();
            Calcular();
        }
    }//GEN-LAST:event_btnGuardarEFActionPerformed

    private void btnActualizarEFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarEFActionPerformed
         if(txtNombreEF.getText().isEmpty() || txtMontoEF.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Ningun campo puede quedar vacio");
        }else{
            ActualizarAct_Pas();
            DefaultTableModel modelo = (DefaultTableModel) jTableEF.getModel();
            Limpiar();
            DeshabilitarTF();
            btnNuevoEF.setEnabled(true);
            btnGuardarEF.setEnabled(false);
            btnActualizarEF.setEnabled(false);
            btnCancelarEF.setEnabled(false); 
            for( int i = modelo.getRowCount() - 1; i >= 0; i-- ) {
                modelo.removeRow(i);
            }
            InsertarAct_Pas();
        }
    }//GEN-LAST:event_btnActualizarEFActionPerformed

    private void btnCancelarEFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarEFActionPerformed
        DeshabilitarTF();
        btnNuevoEF.setEnabled(true);
        btnGuardarEF.setEnabled(false);
        btnActualizarEF.setEnabled(false);
        btnCancelarEF.setEnabled(false);
        Limpiar();
    }//GEN-LAST:event_btnCancelarEFActionPerformed

    private void btnNuevoRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoRActionPerformed
        DefaultTableModel modelo = (DefaultTableModel) jTableEF.getModel(); 
        btnNuevoEF.setEnabled(true);
        btnGenrerEF.setEnabled(true);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        lblFechaAct.setText(String.valueOf(dtf.format(LocalDateTime.now())));
        btnNuevoR.setEnabled(false);
        for( int i = modelo.getRowCount() - 1; i >= 0; i-- ) {
                modelo.removeRow(i);
            }
        NuevoEF();
    }//GEN-LAST:event_btnNuevoRActionPerformed

    private void btnGenrerEFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenrerEFActionPerformed
        btnNuevoR.setEnabled(true);
        PdfEstadoF pdf = new PdfEstadoF("EstadoFinanciero",
                new Date().toString(),
                "C:\\Users\\diana\\Desktop\\5to Semestre\\Seminario de Ingenieria de Software I\\Versiones Proyecto\\Baluarte3\\Baluarte3\\EstadosF");
        try {
            pdf.crearPdf(UltimoID());
        } catch (FileNotFoundException ex) {
            //Logger.getLogger(EstadoFinanciero.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnGenrerEFActionPerformed

    public void HabilitarTF(){
        txtNombreEF.setEnabled(true);
        txtMontoEF.setEnabled(true);
        jrbActivo.setEnabled(true);
        jrbPasivo.setEnabled(true);
    }
    public void DeshabilitarTF(){
        txtNombreEF.setEnabled(false);
        txtMontoEF.setEnabled(false);
        jrbActivo.setEnabled(false);
        jrbPasivo.setEnabled(false);
    }
    
    public void Limpiar(){
        txtNombreEF.setText(null);
        txtMontoEF.setText(null);
        jrbActivo.setSelected(false);
        jrbPasivo.setSelected(false);
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EstadoFinanciero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EstadoFinanciero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EstadoFinanciero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EstadoFinanciero.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EstadoFinanciero().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ISlbl;
    private javax.swing.JLabel Usuario_lbl10;
    private javax.swing.JLabel Usuario_lbl11;
    private javax.swing.JLabel Usuario_lbl13;
    private javax.swing.JLabel Usuario_lbl3;
    private javax.swing.JLabel Usuario_lbl4;
    private javax.swing.JLabel Usuario_lbl5;
    private javax.swing.JLabel Usuario_lbl8;
    private javax.swing.JButton btnActualizarEF;
    private javax.swing.JButton btnCancelarEF;
    private javax.swing.JButton btnGenrerEF;
    private javax.swing.JButton btnGuardarEF;
    private javax.swing.JButton btnInicioP1;
    private javax.swing.JButton btnNuevoEF;
    private javax.swing.JButton btnNuevoR;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableEF;
    private javax.swing.JRadioButton jrbActivo;
    private javax.swing.JRadioButton jrbPasivo;
    private javax.swing.JLabel lblFechaAct;
    private javax.swing.JLabel lblTotalAct;
    private javax.swing.JLabel lblTotalPas;
    private javax.swing.JTextField txtMontoEF;
    private javax.swing.JTextField txtNombreEF;
    // End of variables declaration//GEN-END:variables
}


import java.awt.Color;
import static java.awt.Frame.MAXIMIZED_BOTH;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.table.DefaultTableModel;



/**
 *
 * @author diana
 */
public class GenerarReporte extends javax.swing.JFrame {


    public GenerarReporte() {
        initComponents();
        GraphicsDevice Gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
        int width = Gd.getDisplayMode().getWidth();
        int height = Gd.getDisplayMode().getHeight();
        this.setSize(width,height);
        Color azul = new Color(62, 95, 138); // Color azul
        this.getContentPane().setBackground(azul); //Cambiar color de fondo
        setExtendedState(MAXIMIZED_BOTH);
        InsertarEmpleadosT();
    }

    public void InsertarEmpleadosT(){
        DefaultTableModel modelo = (DefaultTableModel) jTableE2.getModel(); 
        String datos[] =  new String[3];
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            //JOptionPane.showMessageDialog(null, "BD conectada con exito");
            java.sql.Statement st = conn.createStatement();
            
            String sql = "select * from empleado";
            ResultSet res = st.executeQuery(sql);
            
            while(res.next()){
                datos[0] = res.getString("id_empleado");
                datos[1] = res.getString("nombre");
                datos[2] = res.getString("evaluacion");
                modelo.addRow(datos);
            }
            
            st.executeUpdate(sql);
            conn.close();
            st.close();
            
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Error " + e);
        } 
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Usuario_lbl3 = new javax.swing.JLabel();
        Usuario_lbl4 = new javax.swing.JLabel();
        txtIDER = new javax.swing.JTextField();
        txtNumE = new javax.swing.JTextField();
        Usuario_lbl10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableE = new javax.swing.JTable();
        txtNombreR = new javax.swing.JTextField();
        Usuario_lbl14 = new javax.swing.JLabel();
        ISlbl1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableE2 = new javax.swing.JTable();
        btnReporte = new javax.swing.JButton();
        btnInicioP1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(87, 131, 188));
        jPanel1.setLayout(null);

        Usuario_lbl3.setFont(new java.awt.Font("Microsoft YaHei", 1, 24)); // NOI18N
        Usuario_lbl3.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl3.setText("EMPLEADO");
        jPanel1.add(Usuario_lbl3);
        Usuario_lbl3.setBounds(200, 40, 150, 50);

        Usuario_lbl4.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl4.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl4.setText("Nombre");
        jPanel1.add(Usuario_lbl4);
        Usuario_lbl4.setBounds(60, 200, 150, 50);

        txtIDER.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtIDER.setEnabled(false);
        jPanel1.add(txtIDER);
        txtIDER.setBounds(60, 140, 190, 50);

        txtNumE.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtNumE.setEnabled(false);
        jPanel1.add(txtNumE);
        txtNumE.setBounds(290, 140, 190, 50);

        Usuario_lbl10.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl10.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl10.setText("Núm Evaluciones");
        jPanel1.add(Usuario_lbl10);
        Usuario_lbl10.setBounds(290, 100, 260, 50);

        jTableE.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        jTableE.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "CURP", "Profesión", "Cuenta Cotizl", "Fecha de Nac", "NSS", "Domicilio", "Teléfono", "Salario Diario", "Estado"
            }
        ));
        jTableE.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jTableE.setColumnSelectionAllowed(true);
        jTableE.setRowHeight(35);
        jTableE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableEMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableE);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(650, 150, 650, 350);

        txtNombreR.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtNombreR.setEnabled(false);
        jPanel1.add(txtNombreR);
        txtNombreR.setBounds(60, 250, 420, 50);

        Usuario_lbl14.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl14.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl14.setText("ID");
        jPanel1.add(Usuario_lbl14);
        Usuario_lbl14.setBounds(60, 100, 150, 50);

        ISlbl1.setFont(new java.awt.Font("Microsoft YaHei", 1, 36)); // NOI18N
        ISlbl1.setForeground(new java.awt.Color(255, 255, 255));
        ISlbl1.setText("REPORTE");

        jTableE2.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        jTableE2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "Num Evauaciones"
            }
        ));
        jTableE2.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jTableE2.setColumnSelectionAllowed(true);
        jTableE2.setRowHeight(35);
        jTableE2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableE2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTableE2);
        jTableE2.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        if (jTableE2.getColumnModel().getColumnCount() > 0) {
            jTableE2.getColumnModel().getColumn(1).setPreferredWidth(350);
            jTableE2.getColumnModel().getColumn(2).setPreferredWidth(150);
        }

        btnReporte.setBackground(new java.awt.Color(202, 223, 251));
        btnReporte.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnReporte.setForeground(new java.awt.Color(25, 55, 87));
        btnReporte.setText("Generar Reporte");
        btnReporte.setEnabled(false);
        btnReporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReporteActionPerformed(evt);
            }
        });

        btnInicioP1.setBackground(new java.awt.Color(202, 223, 251));
        btnInicioP1.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnInicioP1.setForeground(new java.awt.Color(25, 55, 87));
        btnInicioP1.setText("Volver");
        btnInicioP1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInicioP1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(650, 650, 650)
                .addComponent(ISlbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(240, 240, 240)
                .addComponent(btnInicioP1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 580, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(760, 760, 760)
                .addComponent(btnReporte, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(ISlbl1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnInicioP1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(80, 80, 80)
                .addComponent(btnReporte, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTableEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableEMouseClicked
        
        
    }//GEN-LAST:event_jTableEMouseClicked

    private void jTableE2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableE2MouseClicked
        int select = jTableE2.getSelectedRow();
        txtIDER.setText(jTableE2.getValueAt(select, 0).toString());
        txtNombreR.setText(jTableE2.getValueAt(select, 2).toString());
        txtNumE.setText(jTableE2.getValueAt(select, 1).toString());

        btnReporte.setEnabled(true);
    }//GEN-LAST:event_jTableE2MouseClicked

    private void btnReporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReporteActionPerformed
       
    }//GEN-LAST:event_btnReporteActionPerformed

    private void btnInicioP1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInicioP1ActionPerformed
        RecursosHumanos ven=new RecursosHumanos();
        ven.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnInicioP1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GenerarReporte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GenerarReporte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GenerarReporte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GenerarReporte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GenerarReporte().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ISlbl1;
    private javax.swing.JLabel Usuario_lbl10;
    private javax.swing.JLabel Usuario_lbl14;
    private javax.swing.JLabel Usuario_lbl3;
    private javax.swing.JLabel Usuario_lbl4;
    private javax.swing.JButton btnInicioP1;
    private javax.swing.JButton btnReporte;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableE;
    private javax.swing.JTable jTableE2;
    private javax.swing.JTextField txtIDER;
    private javax.swing.JTextField txtNombreR;
    private javax.swing.JTextField txtNumE;
    // End of variables declaration//GEN-END:variables
}

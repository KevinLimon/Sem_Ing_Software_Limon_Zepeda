
import java.awt.Color;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 * @authors Diana Zepeda & Kevin Limón
 */
public class Inventario extends javax.swing.JFrame {

    /**
     * Creates new form Inventario
     */
    public Inventario() {
        initComponents();
        GraphicsDevice Gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
        int width = Gd.getDisplayMode().getWidth();
        int height = Gd.getDisplayMode().getHeight();
        this.setSize(width,height);
        Color azul = new Color(62, 95, 138); // Color azul
        this.getContentPane().setBackground(azul); //Cambiar color de fondo
        setExtendedState(MAXIMIZED_BOTH);
        
        InsertarProductosT();
    }

    public void GuardarProducto(){
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            java.sql.Statement st = conn.createStatement();
            String total = String.valueOf(Integer.parseInt(txtCantidadP.getText())*Integer.parseInt(txtValUnP.getText()));
            String sql = "insert into producto (nombre, cantidad, valorunitario, valortotal, descripcion)"
                    + "values('" + txtNombreP.getText() + "'," + txtCantidadP.getText() + "," + txtValUnP.getText() + "," + 
                    total + ",'" + jtDes.getText() + "')";
            ResultSet result = st.executeQuery(sql);
            st.executeUpdate(sql);
            conn.close();
            st.close();
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Error " + e);
        }  
        JOptionPane.showMessageDialog(null, "Se ha guardado con exito");
    }
    
    public void ActualizarProducto(){
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            java.sql.Statement st = conn.createStatement();  
            String total = String.valueOf(Integer.parseInt(txtCantidadP.getText())*Integer.parseInt(txtValUnP.getText()));
            String sql = "update producto set nombre='" + txtNombreP.getText() + "',cantidad=" + txtCantidadP.getText() + ",valorunitario=" +  
                    txtValUnP.getText() + ", valortotal=" + total + ",descripcion='" + jtDes.getText() + 
                    "' where idproducto=" + txtIDP.getText();
            ResultSet result = st.executeQuery(sql);
            st.executeUpdate(sql);
            conn.close();
            st.close();
            
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Error " + e);
        }  
        JOptionPane.showMessageDialog(null, "Se ha actualizado con exito");
    }
    
    public void InsertarProductosT(){
        DefaultTableModel modelo = (DefaultTableModel) jTableP.getModel(); 
        //modelo.setAutoResizeMode(jTableE.AUTO_RESIZE_OFF);
        String datos[] =  new String[6];
        ArrayList<String> ListID = new ArrayList();
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            //JOptionPane.showMessageDialog(null, "BD conectada con exito");
            java.sql.Statement st = conn.createStatement();
            
            String sql = "select * from producto";
            ResultSet res = st.executeQuery(sql);
            
            while(res.next()){
                datos[0] = res.getString("idproducto");
                datos[1] = res.getString("nombre");
                datos[2] = res.getString("cantidad");
                datos[3] = res.getString("valorunitario");
                datos[4] = res.getString("valortotal");
                datos[5] = res.getString("descripcion");
                modelo.addRow(datos);
            }
            
            st.executeUpdate(sql);
            conn.close();
            st.close();
            
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Error " + e);
        }         
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Usuario_lbl3 = new javax.swing.JLabel();
        Usuario_lbl4 = new javax.swing.JLabel();
        Usuario_lbl6 = new javax.swing.JLabel();
        Usuario_lbl7 = new javax.swing.JLabel();
        Usuario_lbl8 = new javax.swing.JLabel();
        Usuario_lbl9 = new javax.swing.JLabel();
        txtValTotP = new javax.swing.JTextField();
        txtIDP = new javax.swing.JTextField();
        txtNombreP = new javax.swing.JTextField();
        txtCantidadP = new javax.swing.JTextField();
        txtValUnP = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtDes = new javax.swing.JTextArea();
        Usuario_lbl5 = new javax.swing.JLabel();
        ISlbl = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableP = new javax.swing.JTable();
        btnNuevoP = new javax.swing.JButton();
        btnGuardarP = new javax.swing.JButton();
        btnActualizarP = new javax.swing.JButton();
        btnCancelarP = new javax.swing.JButton();
        btnInicioP = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(87, 131, 188));
        jPanel1.setLayout(null);

        Usuario_lbl3.setFont(new java.awt.Font("Microsoft YaHei", 1, 24)); // NOI18N
        Usuario_lbl3.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl3.setText("PRODUCTO");
        jPanel1.add(Usuario_lbl3);
        Usuario_lbl3.setBounds(180, 20, 150, 50);

        Usuario_lbl4.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl4.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl4.setText("Nombre");
        jPanel1.add(Usuario_lbl4);
        Usuario_lbl4.setBounds(70, 170, 150, 50);

        Usuario_lbl6.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl6.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl6.setText("Descripción");
        jPanel1.add(Usuario_lbl6);
        Usuario_lbl6.setBounds(70, 370, 150, 50);

        Usuario_lbl7.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl7.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl7.setText("ID");
        jPanel1.add(Usuario_lbl7);
        Usuario_lbl7.setBounds(70, 80, 150, 50);

        Usuario_lbl8.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl8.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl8.setText("Valor Total");
        jPanel1.add(Usuario_lbl8);
        Usuario_lbl8.setBounds(280, 270, 150, 50);

        Usuario_lbl9.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl9.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl9.setText("Valor Unitario");
        jPanel1.add(Usuario_lbl9);
        Usuario_lbl9.setBounds(70, 270, 190, 50);

        txtValTotP.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtValTotP.setEnabled(false);
        jPanel1.add(txtValTotP);
        txtValTotP.setBounds(280, 320, 170, 50);

        txtIDP.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtIDP.setEnabled(false);
        jPanel1.add(txtIDP);
        txtIDP.setBounds(70, 120, 170, 50);

        txtNombreP.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtNombreP.setEnabled(false);
        jPanel1.add(txtNombreP);
        txtNombreP.setBounds(70, 220, 380, 50);

        txtCantidadP.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtCantidadP.setEnabled(false);
        jPanel1.add(txtCantidadP);
        txtCantidadP.setBounds(280, 120, 170, 50);

        txtValUnP.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtValUnP.setEnabled(false);
        jPanel1.add(txtValUnP);
        txtValUnP.setBounds(70, 320, 170, 50);

        jtDes.setColumns(20);
        jtDes.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        jtDes.setRows(5);
        jtDes.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jtDes.setEnabled(false);
        jScrollPane2.setViewportView(jtDes);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(70, 410, 380, 150);

        Usuario_lbl5.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl5.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl5.setText("Cantidad");
        jPanel1.add(Usuario_lbl5);
        Usuario_lbl5.setBounds(280, 80, 150, 50);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(50, 40, 520, 610);

        ISlbl.setFont(new java.awt.Font("Microsoft YaHei", 1, 36)); // NOI18N
        ISlbl.setForeground(new java.awt.Color(255, 255, 255));
        ISlbl.setText("INVENTARIO");
        getContentPane().add(ISlbl);
        ISlbl.setBounds(650, 60, 320, 60);

        jTableP.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        jTableP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "Cantidad", "Valor Unitario", "Valor Total", "Descripción"
            }
        ));
        jTableP.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jTableP.setRowHeight(35);
        jTableP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableP);
        if (jTableP.getColumnModel().getColumnCount() > 0) {
            jTableP.getColumnModel().getColumn(1).setPreferredWidth(300);
            jTableP.getColumnModel().getColumn(2).setPreferredWidth(150);
            jTableP.getColumnModel().getColumn(3).setPreferredWidth(150);
            jTableP.getColumnModel().getColumn(4).setPreferredWidth(150);
            jTableP.getColumnModel().getColumn(5).setPreferredWidth(350);
        }

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(660, 150, 650, 350);

        btnNuevoP.setBackground(new java.awt.Color(202, 223, 251));
        btnNuevoP.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnNuevoP.setForeground(new java.awt.Color(25, 55, 87));
        btnNuevoP.setText("Nuevo");
        btnNuevoP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoPActionPerformed(evt);
            }
        });
        getContentPane().add(btnNuevoP);
        btnNuevoP.setBounds(690, 560, 120, 50);

        btnGuardarP.setBackground(new java.awt.Color(202, 223, 251));
        btnGuardarP.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnGuardarP.setForeground(new java.awt.Color(25, 55, 87));
        btnGuardarP.setText("Guardar");
        btnGuardarP.setEnabled(false);
        btnGuardarP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarPActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardarP);
        btnGuardarP.setBounds(840, 560, 120, 50);

        btnActualizarP.setBackground(new java.awt.Color(202, 223, 251));
        btnActualizarP.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnActualizarP.setForeground(new java.awt.Color(25, 55, 87));
        btnActualizarP.setText("Actualizar");
        btnActualizarP.setEnabled(false);
        btnActualizarP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarPActionPerformed(evt);
            }
        });
        getContentPane().add(btnActualizarP);
        btnActualizarP.setBounds(990, 560, 120, 50);

        btnCancelarP.setBackground(new java.awt.Color(202, 223, 251));
        btnCancelarP.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnCancelarP.setForeground(new java.awt.Color(25, 55, 87));
        btnCancelarP.setText("Cancelar");
        btnCancelarP.setEnabled(false);
        btnCancelarP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarPActionPerformed(evt);
            }
        });
        getContentPane().add(btnCancelarP);
        btnCancelarP.setBounds(1140, 560, 120, 50);

        btnInicioP.setBackground(new java.awt.Color(202, 223, 251));
        btnInicioP.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnInicioP.setForeground(new java.awt.Color(25, 55, 87));
        btnInicioP.setText("Volver");
        btnInicioP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInicioPActionPerformed(evt);
            }
        });
        getContentPane().add(btnInicioP);
        btnInicioP.setBounds(1210, 20, 120, 50);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevoPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoPActionPerformed
        HabilitarTF();
        btnNuevoP.setEnabled(false);
        btnGuardarP.setEnabled(true);
        btnActualizarP.setEnabled(false);
        btnCancelarP.setEnabled(true); 
    }//GEN-LAST:event_btnNuevoPActionPerformed

    private void btnGuardarPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarPActionPerformed
        if(txtNombreP.getText().isEmpty() || txtCantidadP.getText().isEmpty() || txtValUnP.getText().isEmpty() || jtDes.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Ningun campo puede quedar vacio");
        }else{
            GuardarProducto();
            DefaultTableModel modelo = (DefaultTableModel) jTableP.getModel();
            Limpiar();
            DeshabilitarTF();
            btnNuevoP.setEnabled(true);
            btnGuardarP.setEnabled(false);
            btnActualizarP.setEnabled(false);
            btnCancelarP.setEnabled(false); 
            for( int i = modelo.getRowCount() - 1; i >= 0; i-- ) {
                modelo.removeRow(i);
            }
            InsertarProductosT();
        }
    }//GEN-LAST:event_btnGuardarPActionPerformed

    private void btnActualizarPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarPActionPerformed
         if(txtNombreP.getText().isEmpty() || txtCantidadP.getText().isEmpty() || txtValUnP.getText().isEmpty() || jtDes.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Ningun campo puede quedar vacio");
        }else{
            ActualizarProducto();
            DefaultTableModel modelo = (DefaultTableModel) jTableP.getModel();
            Limpiar();
            DeshabilitarTF();
            btnNuevoP.setEnabled(true);
            btnGuardarP.setEnabled(false);
            btnActualizarP.setEnabled(false);
            btnCancelarP.setEnabled(false); 
            for( int i = modelo.getRowCount() - 1; i >= 0; i-- ) {
                modelo.removeRow(i);
            }
            InsertarProductosT();
        }
    }//GEN-LAST:event_btnActualizarPActionPerformed

    private void btnCancelarPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarPActionPerformed
        DeshabilitarTF();
        btnNuevoP.setEnabled(true);
        btnGuardarP.setEnabled(false);
        btnActualizarP.setEnabled(false);
        btnCancelarP.setEnabled(false);
        Limpiar();
    }//GEN-LAST:event_btnCancelarPActionPerformed

    private void btnInicioPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInicioPActionPerformed
        Administrador ven=new Administrador();
        ven.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnInicioPActionPerformed

    private void jTablePMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePMouseClicked
        int select = jTableP.getSelectedRow();
        txtIDP.setText(jTableP.getValueAt(select, 0).toString());
        txtNombreP.setText(jTableP.getValueAt(select, 1).toString());
        txtCantidadP.setText(jTableP.getValueAt(select, 2).toString());
        txtValUnP.setText(jTableP.getValueAt(select, 3).toString());
        txtValTotP.setText(jTableP.getValueAt(select, 4).toString());
        jtDes.setText(jTableP.getValueAt(select, 5).toString());
        HabilitarTF();
        btnNuevoP.setEnabled(false);
        btnGuardarP.setEnabled(false);
        btnActualizarP.setEnabled(true);
        btnCancelarP.setEnabled(true);
    }//GEN-LAST:event_jTablePMouseClicked

    public void HabilitarTF(){
        txtNombreP.setEnabled(true);
        txtCantidadP.setEnabled(true);
        txtValUnP.setEnabled(true);
        jtDes.setEnabled(true);
    }
    public void DeshabilitarTF(){
        txtIDP.setEnabled(false);
        txtNombreP.setEnabled(false);
        txtCantidadP.setEnabled(false);
        txtValUnP.setEnabled(false);
        txtValTotP.setEnabled(false);
        jtDes.setEnabled(false);
    }
    
    public void Limpiar(){
        txtIDP.setText(null);
        txtNombreP.setText(null);
        txtCantidadP.setText(null);
        txtValUnP.setText(null);
        txtValTotP.setText(null);
        jtDes.setText(null);
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inventario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inventario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ISlbl;
    private javax.swing.JLabel Usuario_lbl3;
    private javax.swing.JLabel Usuario_lbl4;
    private javax.swing.JLabel Usuario_lbl5;
    private javax.swing.JLabel Usuario_lbl6;
    private javax.swing.JLabel Usuario_lbl7;
    private javax.swing.JLabel Usuario_lbl8;
    private javax.swing.JLabel Usuario_lbl9;
    private javax.swing.JButton btnActualizarP;
    private javax.swing.JButton btnCancelarP;
    private javax.swing.JButton btnGuardarP;
    private javax.swing.JButton btnInicioP;
    private javax.swing.JButton btnNuevoP;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableP;
    private javax.swing.JTextArea jtDes;
    private javax.swing.JTextField txtCantidadP;
    private javax.swing.JTextField txtIDP;
    private javax.swing.JTextField txtNombreP;
    private javax.swing.JTextField txtValTotP;
    private javax.swing.JTextField txtValUnP;
    // End of variables declaration//GEN-END:variables
}


import java.awt.Color;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 * @authors Diana Zepeda & Kevin Limón
 */
public class Empleado extends javax.swing.JFrame {


    public Empleado() {
        initComponents();
        GraphicsDevice Gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
        int width = Gd.getDisplayMode().getWidth();
        int height = Gd.getDisplayMode().getHeight();
        this.setSize(width,height);
        Color azul = new Color(62, 95, 138); // Color azul
        this.getContentPane().setBackground(azul); //Cambiar color de fondo
        setExtendedState(MAXIMIZED_BOTH);
        
        InsertarEmpleadosT();
    }
    
    public void GuardarEmpleado(){
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        String activo;
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            //JOptionPane.showMessageDialog(null, "BD conectada con exito");
            java.sql.Statement st = conn.createStatement();
            if(cbActivo.isSelected()){
                activo = "true";
            }else{
                activo = "false";
            }
             SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String sql = "insert into empleado (nombre, profesion, telefono, fechanac, domicilio, salariod, curp, estado, nss, cuentacot)"
                    + "values('" + txtNombreE.getText() + "','" + txtProfesionE.getText() + "','" + txtTel.getText() + "','" + sdf.format(jdFechaNac.getDate())
                    + "','" + txtDom.getText() + "'," + txtSalD.getText() + ",'" + txtCURP.getText() + "'," +  activo + ",'" + txtNSS.getText() + "','" 
                    + txtCuentaCot.getText() + "')";
            ResultSet result = st.executeQuery(sql);
            //String insert="INSERT INTO info VALUES('"+name+"','"+contactno+"');";
            st.executeUpdate(sql);
            conn.close();
            st.close();
            
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Error " + e);
        }  
        JOptionPane.showMessageDialog(null, "Se ha guardado con exito");
    }
    
    public void ActualizarEmpledo(){
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        String activo;
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            //JOptionPane.showMessageDialog(null, "BD conectada con exito");
            java.sql.Statement st = conn.createStatement();
            if(cbActivo.isSelected()){
                activo = "true";
            }else{
                activo = "false";
            }      
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String sql = "update empleado set nombre='" + txtNombreE.getText() + "',profesion='" + txtProfesionE.getText() + "',telefono='" +  
                    txtTel.getText() + "', fechanac='" + sdf.format(jdFechaNac.getDate()) + "',domicilio='" + txtDom.getText() + "', salariod=" +
                    txtSalD.getText() + ",curp='" + txtCURP.getText() + "', estado=" + activo + ",nss='" + txtNSS.getText() + "',cuentacot='" +
                    txtCuentaCot.getText() + "' where id_empleado=" + txtIDE.getText();
            ResultSet result = st.executeQuery(sql);
            st.executeUpdate(sql);
            conn.close();
            st.close();
            
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Error " + e);
        }  
        JOptionPane.showMessageDialog(null, "Se ha actualizado con exito");
    }
    
    public void InsertarEmpleadosT(){
        DefaultTableModel modelo = (DefaultTableModel) jTableE.getModel(); 
        //modelo.setAutoResizeMode(jTableE.AUTO_RESIZE_OFF);
        String datos[] =  new String[11];
        ArrayList<String> ListID = new ArrayList();
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            //JOptionPane.showMessageDialog(null, "BD conectada con exito");
            java.sql.Statement st = conn.createStatement();
            
            String sql = "select * from empleado";
            ResultSet res = st.executeQuery(sql);
            
            while(res.next()){
                datos[0] = res.getString("id_empleado");
                datos[1] = res.getString("nombre");
                datos[2] = res.getString("curp");
                datos[3] = res.getString("profesion");
                datos[4] = res.getString("cuentaCot");
                datos[5] = res.getString("fechaNac");
                datos[6] = res.getString("nss");
                datos[7] = res.getString("domicilio");
                datos[8] = res.getString("telefono");
                datos[9] = res.getString("salariod");
                if(res.getString("estado").equals("t")){
                    datos[10] = "activo";
                }else{
                    datos[10] = "no activo";
                }
                modelo.addRow(datos);
            }
            
            st.executeUpdate(sql);
            conn.close();
            st.close();
            
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Error " + e);
        } 
 
        //Hacer selecr para hacer las listas
        /*for(int i = 0; i<listaID.size(); i++){
            modelo.addRow(new Object[]{listaID.get(i),listaNom.get(i),listaPre.get(i),listaEx.get(i)});
        }*/
        
    }
    
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnNuevoE = new javax.swing.JButton();
        btnGuardarE = new javax.swing.JButton();
        btnActualizarE = new javax.swing.JButton();
        btnCancelarE = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableE = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        Usuario_lbl3 = new javax.swing.JLabel();
        Usuario_lbl4 = new javax.swing.JLabel();
        Usuario_lbl5 = new javax.swing.JLabel();
        Usuario_lbl6 = new javax.swing.JLabel();
        Usuario_lbl7 = new javax.swing.JLabel();
        Usuario_lbl8 = new javax.swing.JLabel();
        Usuario_lbl9 = new javax.swing.JLabel();
        txtCURP = new javax.swing.JTextField();
        txtIDE = new javax.swing.JTextField();
        txtNombreE = new javax.swing.JTextField();
        txtSalD = new javax.swing.JTextField();
        txtDom = new javax.swing.JTextField();
        txtCuentaCot = new javax.swing.JTextField();
        txtNSS = new javax.swing.JTextField();
        Usuario_lbl10 = new javax.swing.JLabel();
        Usuario_lbl11 = new javax.swing.JLabel();
        txtProfesionE = new javax.swing.JTextField();
        Usuario_lbl12 = new javax.swing.JLabel();
        txtTel = new javax.swing.JTextField();
        Usuario_lbl13 = new javax.swing.JLabel();
        cbActivo = new javax.swing.JCheckBox();
        jdFechaNac = new com.toedter.calendar.JDateChooser();
        ISlbl = new javax.swing.JLabel();
        btnInicioP = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        btnNuevoE.setBackground(new java.awt.Color(202, 223, 251));
        btnNuevoE.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnNuevoE.setForeground(new java.awt.Color(25, 55, 87));
        btnNuevoE.setText("Nuevo");
        btnNuevoE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoEActionPerformed(evt);
            }
        });
        getContentPane().add(btnNuevoE);
        btnNuevoE.setBounds(690, 560, 120, 50);

        btnGuardarE.setBackground(new java.awt.Color(202, 223, 251));
        btnGuardarE.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnGuardarE.setForeground(new java.awt.Color(25, 55, 87));
        btnGuardarE.setText("Guardar");
        btnGuardarE.setEnabled(false);
        btnGuardarE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarEActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardarE);
        btnGuardarE.setBounds(840, 560, 120, 50);

        btnActualizarE.setBackground(new java.awt.Color(202, 223, 251));
        btnActualizarE.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnActualizarE.setForeground(new java.awt.Color(25, 55, 87));
        btnActualizarE.setText("Actualizar");
        btnActualizarE.setEnabled(false);
        btnActualizarE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarEActionPerformed(evt);
            }
        });
        getContentPane().add(btnActualizarE);
        btnActualizarE.setBounds(990, 560, 120, 50);

        btnCancelarE.setBackground(new java.awt.Color(202, 223, 251));
        btnCancelarE.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnCancelarE.setForeground(new java.awt.Color(25, 55, 87));
        btnCancelarE.setText("Cancelar");
        btnCancelarE.setEnabled(false);
        btnCancelarE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarEActionPerformed(evt);
            }
        });
        getContentPane().add(btnCancelarE);
        btnCancelarE.setBounds(1140, 560, 120, 50);

        jTableE.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        jTableE.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "CURP", "Profesión", "Cuenta Cotizl", "Fecha de Nac", "NSS", "Domicilio", "Teléfono", "Salario Diario", "Estado"
            }
        ));
        jTableE.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jTableE.setColumnSelectionAllowed(true);
        jTableE.setRowHeight(35);
        jTableE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableEMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableE);
        jTableE.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        if (jTableE.getColumnModel().getColumnCount() > 0) {
            jTableE.getColumnModel().getColumn(1).setPreferredWidth(300);
            jTableE.getColumnModel().getColumn(2).setPreferredWidth(250);
            jTableE.getColumnModel().getColumn(3).setPreferredWidth(150);
            jTableE.getColumnModel().getColumn(4).setPreferredWidth(150);
            jTableE.getColumnModel().getColumn(5).setPreferredWidth(140);
            jTableE.getColumnModel().getColumn(6).setPreferredWidth(150);
            jTableE.getColumnModel().getColumn(7).setPreferredWidth(300);
            jTableE.getColumnModel().getColumn(8).setPreferredWidth(200);
            jTableE.getColumnModel().getColumn(9).setPreferredWidth(100);
            jTableE.getColumnModel().getColumn(10).setPreferredWidth(100);
        }

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(650, 150, 650, 350);

        jPanel1.setBackground(new java.awt.Color(87, 131, 188));
        jPanel1.setLayout(null);

        Usuario_lbl3.setFont(new java.awt.Font("Microsoft YaHei", 1, 24)); // NOI18N
        Usuario_lbl3.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl3.setText("EMPLEADO");
        jPanel1.add(Usuario_lbl3);
        Usuario_lbl3.setBounds(30, 10, 150, 50);

        Usuario_lbl4.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl4.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl4.setText("Nombre");
        jPanel1.add(Usuario_lbl4);
        Usuario_lbl4.setBounds(70, 140, 150, 50);

        Usuario_lbl5.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl5.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl5.setText("Cuenta Cotiz");
        jPanel1.add(Usuario_lbl5);
        Usuario_lbl5.setBounds(280, 230, 150, 50);

        Usuario_lbl6.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl6.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl6.setText("Salario Diario");
        jPanel1.add(Usuario_lbl6);
        Usuario_lbl6.setBounds(280, 500, 150, 50);

        Usuario_lbl7.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl7.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl7.setText("CURP");
        jPanel1.add(Usuario_lbl7);
        Usuario_lbl7.setBounds(280, 50, 150, 50);

        Usuario_lbl8.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl8.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl8.setText("NSS");
        jPanel1.add(Usuario_lbl8);
        Usuario_lbl8.setBounds(280, 320, 150, 50);

        Usuario_lbl9.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl9.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl9.setText("Fecha de Nac");
        jPanel1.add(Usuario_lbl9);
        Usuario_lbl9.setBounds(70, 320, 190, 50);

        txtCURP.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtCURP.setEnabled(false);
        jPanel1.add(txtCURP);
        txtCURP.setBounds(280, 90, 170, 50);

        txtIDE.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtIDE.setEnabled(false);
        jPanel1.add(txtIDE);
        txtIDE.setBounds(70, 90, 170, 50);

        txtNombreE.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtNombreE.setEnabled(false);
        jPanel1.add(txtNombreE);
        txtNombreE.setBounds(70, 180, 380, 50);

        txtSalD.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtSalD.setEnabled(false);
        jPanel1.add(txtSalD);
        txtSalD.setBounds(280, 540, 170, 50);

        txtDom.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtDom.setEnabled(false);
        jPanel1.add(txtDom);
        txtDom.setBounds(70, 450, 380, 50);

        txtCuentaCot.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtCuentaCot.setEnabled(false);
        jPanel1.add(txtCuentaCot);
        txtCuentaCot.setBounds(280, 270, 170, 50);

        txtNSS.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtNSS.setEnabled(false);
        jPanel1.add(txtNSS);
        txtNSS.setBounds(280, 360, 170, 50);

        Usuario_lbl10.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl10.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl10.setText("ID");
        jPanel1.add(Usuario_lbl10);
        Usuario_lbl10.setBounds(70, 50, 150, 50);

        Usuario_lbl11.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl11.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl11.setText("Profesión");
        jPanel1.add(Usuario_lbl11);
        Usuario_lbl11.setBounds(70, 230, 150, 50);

        txtProfesionE.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtProfesionE.setEnabled(false);
        jPanel1.add(txtProfesionE);
        txtProfesionE.setBounds(70, 270, 170, 50);

        Usuario_lbl12.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl12.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl12.setText("Domicilio");
        jPanel1.add(Usuario_lbl12);
        Usuario_lbl12.setBounds(70, 410, 150, 50);

        txtTel.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtTel.setEnabled(false);
        jPanel1.add(txtTel);
        txtTel.setBounds(70, 540, 170, 50);

        Usuario_lbl13.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl13.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl13.setText("Teléfono");
        jPanel1.add(Usuario_lbl13);
        Usuario_lbl13.setBounds(70, 500, 150, 50);

        cbActivo.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        cbActivo.setForeground(new java.awt.Color(255, 255, 255));
        cbActivo.setText("Activo");
        cbActivo.setEnabled(false);
        cbActivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbActivoActionPerformed(evt);
            }
        });
        jPanel1.add(cbActivo);
        cbActivo.setBounds(410, 20, 90, 33);

        jdFechaNac.setDateFormatString("MM d, yyyy");
        jdFechaNac.setEnabled(false);
        jPanel1.add(jdFechaNac);
        jdFechaNac.setBounds(70, 360, 180, 50);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(50, 30, 520, 630);

        ISlbl.setFont(new java.awt.Font("Microsoft YaHei", 1, 36)); // NOI18N
        ISlbl.setForeground(new java.awt.Color(255, 255, 255));
        ISlbl.setText("EMPLEADOS");
        getContentPane().add(ISlbl);
        ISlbl.setBounds(650, 60, 320, 60);

        btnInicioP.setBackground(new java.awt.Color(202, 223, 251));
        btnInicioP.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnInicioP.setForeground(new java.awt.Color(25, 55, 87));
        btnInicioP.setText("Volver");
        btnInicioP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInicioPActionPerformed(evt);
            }
        });
        getContentPane().add(btnInicioP);
        btnInicioP.setBounds(1210, 20, 120, 50);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevoEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoEActionPerformed
        HabilitarTF();
        btnNuevoE.setEnabled(false);
        btnGuardarE.setEnabled(true);
        btnActualizarE.setEnabled(false);
        btnCancelarE.setEnabled(true); 
    }//GEN-LAST:event_btnNuevoEActionPerformed

    private void btnGuardarEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarEActionPerformed
        if(txtCURP.getText().isEmpty() || txtNombreE.getText().isEmpty() || txtProfesionE.getText().isEmpty() || 
           txtCuentaCot.getText().isEmpty() || txtNSS.getText().isEmpty() ||  txtDom.getText().isEmpty() || txtTel.getText().isEmpty() || 
           txtSalD.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Ningun campo puede quedar vacio");
        }else{
            GuardarEmpleado();
            DefaultTableModel modelo = (DefaultTableModel) jTableE.getModel();
            //modelo.addRow(new Object[]{String.valueOf(contA),txtDesArticulo.getText(),txtPrecioArticulos.getText(),txtExistArticulos.getText()});
            Limpiar();
            DeshabilitarTF();
            btnNuevoE.setEnabled(true);
            btnGuardarE.setEnabled(false);
            btnActualizarE.setEnabled(false);
            btnCancelarE.setEnabled(false); 
            for( int i = modelo.getRowCount() - 1; i >= 0; i-- ) {
                modelo.removeRow(i);
            }
            InsertarEmpleadosT();
        }
    }//GEN-LAST:event_btnGuardarEActionPerformed

    private void btnActualizarEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarEActionPerformed
         if(txtCURP.getText().isEmpty() || txtNombreE.getText().isEmpty() || txtProfesionE.getText().isEmpty() || 
           txtCuentaCot.getText().isEmpty() || txtNSS.getText().isEmpty() ||  txtDom.getText().isEmpty() || txtTel.getText().isEmpty() || 
           txtSalD.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Ningun campo puede quedar vacio");
        }else{
            ActualizarEmpledo();
            DefaultTableModel modelo = (DefaultTableModel) jTableE.getModel();
            //modelo.addRow(new Object[]{String.valueOf(contA),txtDesArticulo.getText(),txtPrecioArticulos.getText(),txtExistArticulos.getText()});
            Limpiar();
            DeshabilitarTF();
            btnNuevoE.setEnabled(true);
            btnGuardarE.setEnabled(false);
            btnActualizarE.setEnabled(false);
            btnCancelarE.setEnabled(false); 
            for( int i = modelo.getRowCount() - 1; i >= 0; i-- ) {
                modelo.removeRow(i);
            }
            InsertarEmpleadosT();
        }
    }//GEN-LAST:event_btnActualizarEActionPerformed

    private void btnCancelarEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarEActionPerformed
        DeshabilitarTF();
        btnNuevoE.setEnabled(true);
        btnGuardarE.setEnabled(false);
        btnActualizarE.setEnabled(false);
        btnCancelarE.setEnabled(false);
        Limpiar();
    }//GEN-LAST:event_btnCancelarEActionPerformed

    private void btnInicioPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInicioPActionPerformed
        RecursosHumanos ven=new RecursosHumanos();
        ven.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnInicioPActionPerformed

    private void cbActivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbActivoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbActivoActionPerformed

    private void jTableEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableEMouseClicked
        int select = jTableE.getSelectedRow();
        txtIDE.setText(jTableE.getValueAt(select, 0).toString());
        txtCURP.setText(jTableE.getValueAt(select, 2).toString());
        txtNombreE.setText(jTableE.getValueAt(select, 1).toString());
        txtProfesionE.setText(jTableE.getValueAt(select, 3).toString());
        txtCuentaCot.setText(jTableE.getValueAt(select, 4).toString());
        String dd = jTableE.getValueAt(select, 5).toString();
        Date date;
        try {
            date = new SimpleDateFormat("yyyy-MM-dd").parse(dd);
            jdFechaNac.setDate(date);
        } catch (ParseException ex) {
            //Logger.getLogger(Empleado.class.getName()).log(Level.SEVERE, null, ex);
        }
        txtNSS.setText(jTableE.getValueAt(select, 6).toString());
        txtDom.setText(jTableE.getValueAt(select, 7).toString());
        txtTel.setText(jTableE.getValueAt(select, 8).toString());
        txtSalD.setText(jTableE.getValueAt(select, 9).toString());
        if(jTableE.getValueAt(select, 10).toString().equals("activo")){
            cbActivo.setSelected(true);
        }else{
            cbActivo.setSelected(false);
        }
        HabilitarTF();
        btnNuevoE.setEnabled(false);
        btnGuardarE.setEnabled(false);
        btnActualizarE.setEnabled(true);
        btnCancelarE.setEnabled(true);
    }//GEN-LAST:event_jTableEMouseClicked

    public void HabilitarTF(){
        txtCURP.setEnabled(true);
        txtNombreE.setEnabled(true);
        txtProfesionE.setEnabled(true);
        txtCuentaCot.setEnabled(true);
        jdFechaNac.setEnabled(true);
        txtNSS.setEnabled(true);
        txtDom.setEnabled(true);
        txtTel.setEnabled(true);
        txtSalD.setEnabled(true);
        cbActivo.setEnabled(true);
    }
    public void DeshabilitarTF(){
        txtIDE.setEnabled(false);
        txtCURP.setEnabled(false);
        txtNombreE.setEnabled(false);
        txtProfesionE.setEnabled(false);
        txtCuentaCot.setEnabled(false);
        jdFechaNac.setEnabled(false);
        txtNSS.setEnabled(false);
        txtDom.setEnabled(false);
        txtTel.setEnabled(false);
        txtSalD.setEnabled(false);
        cbActivo.setEnabled(false);
    }
    
    public void Limpiar(){
        txtIDE.setText(null);
        txtCURP.setText(null);
        txtNombreE.setText(null);
        txtProfesionE.setText(null);
        txtCuentaCot.setText(null);
        //jdFechaNac.setDateFormatString(null);
        txtNSS.setText(null);
        txtDom.setText(null);
        txtTel.setText(null);
        txtSalD.setText(null);
        cbActivo.setSelected(false);
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Empleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Empleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Empleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Empleado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Empleado().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ISlbl;
    private javax.swing.JLabel Usuario_lbl10;
    private javax.swing.JLabel Usuario_lbl11;
    private javax.swing.JLabel Usuario_lbl12;
    private javax.swing.JLabel Usuario_lbl13;
    private javax.swing.JLabel Usuario_lbl3;
    private javax.swing.JLabel Usuario_lbl4;
    private javax.swing.JLabel Usuario_lbl5;
    private javax.swing.JLabel Usuario_lbl6;
    private javax.swing.JLabel Usuario_lbl7;
    private javax.swing.JLabel Usuario_lbl8;
    private javax.swing.JLabel Usuario_lbl9;
    private javax.swing.JButton btnActualizarE;
    private javax.swing.JButton btnCancelarE;
    private javax.swing.JButton btnGuardarE;
    private javax.swing.JButton btnInicioP;
    private javax.swing.JButton btnNuevoE;
    private javax.swing.JCheckBox cbActivo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableE;
    private com.toedter.calendar.JDateChooser jdFechaNac;
    private javax.swing.JTextField txtCURP;
    private javax.swing.JTextField txtCuentaCot;
    private javax.swing.JTextField txtDom;
    private javax.swing.JTextField txtIDE;
    private javax.swing.JTextField txtNSS;
    private javax.swing.JTextField txtNombreE;
    private javax.swing.JTextField txtProfesionE;
    private javax.swing.JTextField txtSalD;
    private javax.swing.JTextField txtTel;
    // End of variables declaration//GEN-END:variables
}

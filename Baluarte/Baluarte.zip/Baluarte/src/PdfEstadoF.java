
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Color;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;



/**
 *
 * @author diana
 */
public class PdfEstadoF {
    String nombreArchivo;
    String fecha;
    String rutaImagen;
    
    Document documento;
    FileOutputStream archivo;
    Paragraph titulo;
    Paragraph espacio;
    
    BaseColor azul1 = new BaseColor(62, 95, 138);
    BaseColor azul2 = new BaseColor(87,131,188);
    BaseColor azul3 = new BaseColor(106,158,222);
    BaseColor azul4 = new BaseColor(160,197,247);
    BaseColor azul5 = new BaseColor(220,223,251);
    BaseColor azul6 = new BaseColor(232,242,255);
    
    public PdfEstadoF(String nombreArchivo,
            String fecha,
            String rutaImagen)
    {
        this.nombreArchivo = nombreArchivo;
        this.fecha = fecha;
        this.rutaImagen = rutaImagen;
        
        documento = new Document();     
        espacio  = new Paragraph(" ");     
    }
    
    public void crearPdf(int id) throws FileNotFoundException{
        try {
            archivo = new FileOutputStream(nombreArchivo + ".pdf");
            PdfWriter.getInstance(documento, archivo);
            documento.open();
            //titulo.setAlignment(1);

            /*Image image = null;
            try {
                image =  Image.getInstance(rutaImagen);//carga imagen
                image.scaleAbsolute(150, 100);//cambia tamaño
                image.setAbsolutePosition(415, 750);//coloca imagen en la posicion
                
            } catch (Exception e) {
            }*/
            
            PdfPTable inicio = new PdfPTable(1);
            inicio.setWidthPercentage(100);
            Font font = new Font();
            font.setColor(BaseColor.WHITE);
            PdfPCell nombreE = new PdfPCell(new Phrase("BALUARTE S.A DE C.V", font));
            nombreE.setBorderColor(azul1);
            nombreE.setBackgroundColor(azul1);
            PdfPCell EF = new PdfPCell(new Phrase("Estado Financiero", font));
            EF.setBorderColor(azul3);
            EF.setBackgroundColor(azul3);
            
            inicio.addCell(nombreE);
            inicio.addCell(EF);
            documento.add(inicio); 
            
            documento.add(Chunk.NEWLINE);
  
            //documento.add(image);//agrega la imagen al documento
            documento.add(espacio);
            
            //documento.add(Chunk.NEWLINE);
            
            PdfPTable estadoF = new PdfPTable(1);
            estadoF.setWidthPercentage(100);
            PdfPCell Act = new PdfPCell(new Phrase("Activos", font));
            Act.setBorderColor(azul2);
            Act.setBackgroundColor(azul2);
            estadoF.addCell(Act);
            documento.add(estadoF);
            
            PdfPTable activos = new PdfPTable(2);
            activos.setWidthPercentage(100);
            PdfPCell nom = new PdfPCell(new Phrase("Nombre"));
            nom.setBorderColor(azul4);
            nom.setBackgroundColor(azul4);
            activos.addCell(nom);
            
            PdfPCell mon = new PdfPCell(new Phrase("Monto"));
            mon.setBorderColor(azul4);
            mon.setBackgroundColor(azul4);
            activos.addCell(mon);

            String BD = "jdbc:postgresql://localhost:5432/baluarte";
            String usuario = "postgres";
            String contra = "lumitylover";
            Connection conn = null;
            int totalActivos = 0;
            try {
                Class.forName("org.postgresql.Driver");
                conn = DriverManager.getConnection(BD, usuario, contra);
                java.sql.Statement st = conn.createStatement();

                String sql = "select * from activo_pasivo where id_estadof="+ id+"and tipo is true";
                ResultSet res = st.executeQuery(sql);

                while(res.next()){
                    nom = new PdfPCell(new Phrase(res.getString("nombre")));
                    nom.setBorderColor(BaseColor.WHITE);
                    activos.addCell(nom);
                    mon = new PdfPCell(new Phrase(res.getString("monto")));
                    mon.setBorderColor(BaseColor.WHITE);
                    activos.addCell(mon);
                    totalActivos = totalActivos + Integer.parseInt(res.getString("monto"));
                }
 
                st.executeUpdate(sql);
                conn.close();
                st.close();

            } catch (Exception e) {
                //JOptionPane.showMessageDialog(null, "Error " + e);
            }
            documento.add(activos); 
            
            PdfPTable totactivos = new PdfPTable(2);
            totactivos.setWidthPercentage(100);
            PdfPCell tot = new PdfPCell(new Phrase("Total Activos"));
            tot.setBorderColor(azul5);
            tot.setBackgroundColor(azul5);
            totactivos.addCell(tot);
            
            PdfPCell tot2 = new PdfPCell(new Phrase(String.valueOf(totalActivos)));
            tot2.setBorderColor(azul5);
            tot2.setBackgroundColor(azul5);
            totactivos.addCell(tot2);
            
            documento.add(totactivos); 
            
            
            //documento.add(new Paragraph("Director: " + nombreArchivo));
                            
            documento.add(Chunk.NEWLINE);
            
            PdfPTable estadoF2 = new PdfPTable(1);
            estadoF2.setWidthPercentage(100);
            PdfPCell Act2 = new PdfPCell(new Phrase("Pasivos", font));
            Act2.setBorderColor(azul2);
            Act2.setBackgroundColor(azul2);
            estadoF2.addCell(Act2);
            documento.add(estadoF2);
            
            PdfPTable pasivos = new PdfPTable(2);
            pasivos .setWidthPercentage(100);
            PdfPCell nom2 = new PdfPCell(new Phrase("Nombre"));
            nom2.setBorderColor(azul4);
            nom2.setBackgroundColor(azul4);
            pasivos.addCell(nom2);
            
            PdfPCell mon2 = new PdfPCell(new Phrase("Monto"));
            mon2.setBorderColor(azul4);
            mon2.setBackgroundColor(azul4);
            pasivos .addCell(mon2);

            conn = null;
            int totalPasivos = 0;
            try {
                Class.forName("org.postgresql.Driver");
                conn = DriverManager.getConnection(BD, usuario, contra);
                java.sql.Statement st = conn.createStatement();

                String sql = "select * from activo_pasivo where id_estadof="+ id+"and tipo is false";
                ResultSet res = st.executeQuery(sql);

                while(res.next()){
                    nom2 = new PdfPCell(new Phrase(res.getString("nombre")));
                    nom2.setBorderColor(BaseColor.WHITE);
                    pasivos.addCell(nom);
                    mon2 = new PdfPCell(new Phrase(res.getString("monto")));
                    mon2.setBorderColor(BaseColor.WHITE);
                    pasivos.addCell(mon);
                    totalPasivos = totalPasivos + Integer.parseInt(res.getString("monto"));
                }
 
                st.executeUpdate(sql);
                conn.close();
                st.close();

            } catch (Exception e) {
                //JOptionPane.showMessageDialog(null, "Error " + e);
            }
            documento.add(pasivos); 
            
            PdfPTable totpasivos = new PdfPTable(2);
            totpasivos.setWidthPercentage(100);
            PdfPCell totp = new PdfPCell(new Phrase("Total Pasivos"));
            totp.setBorderColor(azul6);
            totp.setBackgroundColor(azul6);
            totpasivos.addCell(totp);
            
            PdfPCell totp2 = new PdfPCell(new Phrase(String.valueOf(totalPasivos)));
            totp2.setBorderColor(azul6);
            totp2.setBackgroundColor(azul6);
            totpasivos.addCell(totp2);
            
            documento.add(totpasivos); 
            documento.add(Chunk.NEWLINE);
            
            PdfPTable invent = new PdfPTable(1);
            invent.setWidthPercentage(100);
            PdfPCell inv = new PdfPCell(new Phrase("Inventario", font));
            inv.setBorderColor(azul2);
            inv.setBackgroundColor(azul2);
            invent.addCell(inv);
            documento.add(invent); 
            
            PdfPTable patri = new PdfPTable(2);
            patri.setWidthPercentage(100);
            PdfPCell pat = new PdfPCell(new Phrase("Total Patrimonio Inventario"));
            pat.setBorderColor(azul6);
            pat.setBackgroundColor(azul6);
            patri.addCell(pat);
            
            conn = null;
            int totalPatrimonio = 0;
            try {
                Class.forName("org.postgresql.Driver");
                conn = DriverManager.getConnection(BD, usuario, contra);
                java.sql.Statement st = conn.createStatement();

                String sql = "select * from producto";
                ResultSet res = st.executeQuery(sql);

                while(res.next()){
                    totalPatrimonio = totalPatrimonio + Integer.parseInt(res.getString("valortotal"));
                }
                
                st.executeUpdate(sql);
                conn.close();
                st.close();

            } catch (Exception e) {
                //JOptionPane.showMessageDialog(null, "Error " + e);
            }
            
            PdfPCell pat2 = new PdfPCell(new Phrase(String.valueOf(totalPatrimonio)));
            pat2.setBorderColor(azul6);
            pat2.setBackgroundColor(azul6);
            patri.addCell(pat2);
            
            documento.add(patri); 
            documento.add(Chunk.NEWLINE);
            
            PdfPTable patpas = new PdfPTable(2);
            patpas.setWidthPercentage(100);           
            PdfPCell pasp2 = new PdfPCell(new Phrase("Total Pasivo y Patrimonio"));
            pasp2.setBorderColor(azul5);
            pasp2.setBackgroundColor(azul5);
            patpas.addCell(pasp2);
            
            PdfPCell pasp = new PdfPCell(new Phrase(String.valueOf(totalPasivos+totalPatrimonio)));
            pasp.setBorderColor(azul5);
            pasp.setBackgroundColor(azul5);
            patpas.addCell(pasp);
            
            documento.add(patpas); 
            
            documento.add(Chunk.NEWLINE);
            
            documento.add(new Paragraph("Fecha: " + fecha));
            
            documento.close();
            JOptionPane.showMessageDialog(null, "El archivo PDF se a creado correctamente!");
        } catch(DocumentException e){
            System.err.println(e.getMessage());
        }
        
    }
    
    
}


import java.awt.Color;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 * @authors Diana Zepeda & Kevin Limón
 */
public class Evaluacion extends javax.swing.JFrame {

    public Evaluacion() {
        initComponents();
        GraphicsDevice Gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
        int width = Gd.getDisplayMode().getWidth();
        int height = Gd.getDisplayMode().getHeight();
        this.setSize(width,height);
        Color azul = new Color(62, 95, 138); // Color azul
        this.getContentPane().setBackground(azul); //Cambiar color de fondo
        setExtendedState(MAXIMIZED_BOTH);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        lbl7.setText(String.valueOf(dtf.format(LocalDateTime.now())));
        InsertarEmpleadosT();
    }
    
     public int numEvaluaciones(){
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        int numE = 0;
        
        try{
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            java.sql.Statement st = conn.createStatement();
            String sql = "select * from empleado where id="+txtidempleado.getText(); 
  
            ResultSet result = st.executeQuery(sql);
            numE = Integer.parseInt(result.getString("evaluacion"));
            st.executeUpdate(sql);
            conn.close();
            st.close();
        } catch(Exception e){
            //JOptionPane.showMessageDialog(null, "Error " + e);
        }
        return numE;
        
    }
    
    public void guardarNum(){
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        int numE = numEvaluaciones() + 1;   
        try{
            
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            java.sql.Statement st = conn.createStatement();
         
            String sql = "update evaluacion set evaluacion = "+numE;         
            ResultSet result = st.executeQuery(sql);
            st.executeUpdate(sql);
            conn.close();
            st.close();
        } catch(Exception e){
            //JOptionPane.showMessageDialog(null, "Error " + e);
        }
        JOptionPane.showMessageDialog(null, "Se ha guardado con exito");
        
    } 
     
    public void guardarEvaluacion(){
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;  
        try{
            
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            java.sql.Statement st = conn.createStatement();
            String BO = String.valueOf(jsBO.getValue());
            String MO = String.valueOf(jsMO.getValue());
            String sql = "insert into evaluacion (id_empleado, fecha, malasobs, buenasobs, comentario)" 
                    + "values(" + txtidempleado.getText() + ",'" + lbl7.getText() + "'," + BO + "," + MO + ",'" + txtCom.getText() + "')";
            ResultSet result = st.executeQuery(sql);
            st.executeUpdate(sql);
            conn.close();
            st.close();
        } catch(Exception e){
            //JOptionPane.showMessageDialog(null, "Error " + e);
        }
        guardarNum();
        JOptionPane.showMessageDialog(null, "Se ha guardado con exito");
        
    }
    
    public void InsertarEmpleadosT(){
        DefaultTableModel modelo = (DefaultTableModel) jTableE3.getModel(); 
        String datos[] =  new String[2];
        String BD = "jdbc:postgresql://localhost:5432/baluarte";
        String usuario = "postgres";
        String contra = "lumitylover";
        Connection conn = null;
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(BD, usuario, contra);
            //JOptionPane.showMessageDialog(null, "BD conectada con exito");
            java.sql.Statement st = conn.createStatement();
            
            String sql = "select * from empleado";
            ResultSet res = st.executeQuery(sql);
            
            while(res.next()){
                datos[0] = res.getString("id_empleado");
                datos[1] = res.getString("nombre");
                modelo.addRow(datos);
            }
            
            st.executeUpdate(sql);
            conn.close();
            st.close();
            
        } catch (Exception e) {
            //JOptionPane.showMessageDialog(null, "Error " + e);
        } 
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ISlbl = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        Usuario_lbl4 = new javax.swing.JLabel();
        Usuario_lbl5 = new javax.swing.JLabel();
        lbl9 = new javax.swing.JLabel();
        txtIDEv = new javax.swing.JTextField();
        Usuario_lbl10 = new javax.swing.JLabel();
        Usuario_lbl11 = new javax.swing.JLabel();
        Usuario_lbl8 = new javax.swing.JLabel();
        jsMO = new javax.swing.JSpinner();
        jsBO = new javax.swing.JSpinner();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtCom = new javax.swing.JTextArea();
        txtidempleado = new javax.swing.JTextField();
        lbl7 = new javax.swing.JLabel();
        btnInicioP1 = new javax.swing.JButton();
        btnGuardarEv = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableE3 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        ISlbl.setFont(new java.awt.Font("Microsoft YaHei", 1, 36)); // NOI18N
        ISlbl.setForeground(new java.awt.Color(255, 255, 255));
        ISlbl.setText("EVALUACIÓN");
        getContentPane().add(ISlbl);
        ISlbl.setBounds(260, 20, 320, 60);

        jPanel1.setBackground(new java.awt.Color(87, 131, 188));
        jPanel1.setLayout(null);

        Usuario_lbl4.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl4.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl4.setText("Malas Observaciones");
        jPanel1.add(Usuario_lbl4);
        Usuario_lbl4.setBounds(350, 150, 240, 50);

        Usuario_lbl5.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl5.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl5.setText("Comentarios");
        jPanel1.add(Usuario_lbl5);
        Usuario_lbl5.setBounds(70, 240, 150, 50);

        lbl9.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        lbl9.setForeground(new java.awt.Color(255, 255, 255));
        lbl9.setText("Fecha:");
        jPanel1.add(lbl9);
        lbl9.setBounds(330, 10, 200, 50);

        txtIDEv.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        txtIDEv.setEnabled(false);
        jPanel1.add(txtIDEv);
        txtIDEv.setBounds(70, 100, 230, 50);

        Usuario_lbl10.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl10.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl10.setText("ID");
        jPanel1.add(Usuario_lbl10);
        Usuario_lbl10.setBounds(70, 60, 150, 50);

        Usuario_lbl11.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl11.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl11.setText("Buenas Observaciones");
        jPanel1.add(Usuario_lbl11);
        Usuario_lbl11.setBounds(70, 150, 240, 50);

        Usuario_lbl8.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        Usuario_lbl8.setForeground(new java.awt.Color(255, 255, 255));
        Usuario_lbl8.setText("ID Empleado");
        jPanel1.add(Usuario_lbl8);
        Usuario_lbl8.setBounds(350, 60, 150, 50);

        jsMO.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        jPanel1.add(jsMO);
        jsMO.setBounds(350, 190, 220, 50);

        jsBO.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        jPanel1.add(jsBO);
        jsBO.setBounds(70, 190, 230, 50);

        txtCom.setColumns(20);
        txtCom.setRows(5);
        txtCom.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jScrollPane1.setViewportView(txtCom);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(70, 280, 500, 170);

        txtidempleado.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        jPanel1.add(txtidempleado);
        txtidempleado.setBounds(350, 100, 220, 50);

        lbl7.setFont(new java.awt.Font("Microsoft YaHei", 1, 20)); // NOI18N
        lbl7.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(lbl7);
        lbl7.setBounds(420, 10, 200, 50);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(70, 90, 640, 500);

        btnInicioP1.setBackground(new java.awt.Color(202, 223, 251));
        btnInicioP1.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnInicioP1.setForeground(new java.awt.Color(25, 55, 87));
        btnInicioP1.setText("Volver");
        btnInicioP1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInicioP1ActionPerformed(evt);
            }
        });
        getContentPane().add(btnInicioP1);
        btnInicioP1.setBounds(1210, 20, 120, 50);

        btnGuardarEv.setBackground(new java.awt.Color(202, 223, 251));
        btnGuardarEv.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        btnGuardarEv.setForeground(new java.awt.Color(25, 55, 87));
        btnGuardarEv.setText("Guardar");
        btnGuardarEv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarEvActionPerformed(evt);
            }
        });
        getContentPane().add(btnGuardarEv);
        btnGuardarEv.setBounds(290, 610, 190, 50);

        jTableE3.setFont(new java.awt.Font("Microsoft YaHei", 0, 18)); // NOI18N
        jTableE3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre"
            }
        ));
        jTableE3.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jTableE3.setColumnSelectionAllowed(true);
        jTableE3.setRowHeight(35);
        jTableE3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableE3MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTableE3);
        jTableE3.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        if (jTableE3.getColumnModel().getColumnCount() > 0) {
            jTableE3.getColumnModel().getColumn(1).setPreferredWidth(400);
        }

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(800, 130, 480, 440);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarEvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarEvActionPerformed
        if(txtCom.getText().isEmpty() || txtidempleado.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Ningun campo puede quedar vacio");}
        else{
            guardarEvaluacion();
            limpiar();
        }
        
            
    }//GEN-LAST:event_btnGuardarEvActionPerformed
    private void limpiar(){
        txtidempleado.setText(null);
        jsMO.setValue(0);
        jsBO.setValue(0);
        txtCom.setText(null);
    }
    private void btnInicioP1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInicioP1ActionPerformed
        RecursosHumanos ven=new RecursosHumanos();
        ven.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnInicioP1ActionPerformed

    private void jTableE3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableE3MouseClicked
        int select = jTableE3.getSelectedRow();
        txtidempleado.setText(jTableE3.getValueAt(select, 0).toString());

    }//GEN-LAST:event_jTableE3MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Evaluacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Evaluacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Evaluacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Evaluacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Evaluacion().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ISlbl;
    private javax.swing.JLabel Usuario_lbl10;
    private javax.swing.JLabel Usuario_lbl11;
    private javax.swing.JLabel Usuario_lbl4;
    private javax.swing.JLabel Usuario_lbl5;
    private javax.swing.JLabel Usuario_lbl8;
    private javax.swing.JButton btnGuardarEv;
    private javax.swing.JButton btnInicioP1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableE3;
    private javax.swing.JSpinner jsBO;
    private javax.swing.JSpinner jsMO;
    private javax.swing.JLabel lbl7;
    private javax.swing.JLabel lbl9;
    private javax.swing.JTextArea txtCom;
    private javax.swing.JTextField txtIDEv;
    private javax.swing.JTextField txtidempleado;
    // End of variables declaration//GEN-END:variables
}
